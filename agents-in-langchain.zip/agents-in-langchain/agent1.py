from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.tools import tool
from langchain_community.tools import DuckDuckGoSearchRun
import requests
import os
from dotenv import load_dotenv

load_dotenv()

search_tool = DuckDuckGoSearchRun()

@tool
def get_weather_data(city: str) -> dict:
    """Fetch current weather data for a given city"""
    url = "http://api.weatherstack.com/current"
    params = {
        "access_key": os.environ["WEATHERSTACK_API_KEY"],
        "query": city
    }
    return requests.get(url, params=params).json()

tools = {
    "duckduckgo_search": search_tool,
    "get_weather_data": get_weather_data,
}

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
llm_with_tools = llm.bind_tools(list(tools.values()))

messages = [
    HumanMessage(
        content="Find the capital of bangalore , then get its current weather."
    )
]

# First model call
response = llm_with_tools.invoke(messages)
messages.append(response)

# Execute tools if requested
for tool_call in response.tool_calls:
    tool_name = tool_call["name"]
    tool_args = tool_call["args"]

    tool_result = tools[tool_name].invoke(tool_args)

    messages.append(
        ToolMessage(
            content=str(tool_result),
            tool_call_id=tool_call["id"]
        )
    )

# Final answer
final_response = llm.invoke(messages)
print("\nFINAL ANSWER:\n")
print(final_response.content)
