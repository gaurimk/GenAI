from dotenv import load_dotenv
load_dotenv()   # 👈 THIS LINE IS CRITICAL

from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="gpt-3.5-turbo",
    temperature=0
)

response = llm.invoke("Which is the longest river in world?")
print(response.content)
