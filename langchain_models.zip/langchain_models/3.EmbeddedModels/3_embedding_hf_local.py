from langchain_huggingface import HuggingFaceEmbeddings, HuggingFacePipeline

embedding = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
documents = [
    "Delhi is the capital of India",
    "The capital of France is Paris",
    "Berlin is the capital of Germany",
]
result = embedding.embed_documents(documents)
print(str(result))