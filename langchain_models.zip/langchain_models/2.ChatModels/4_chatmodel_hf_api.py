from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from dotenv import load_dotenv

load_dotenv()

llm = HuggingFaceEndpoint(
    repo_id="TinyLlama/TinyLlama-1.1B-Chat-v1.0",
    task="text-generation",
    max_new_tokens=128,
    temperature=0.5,
)

model = ChatHuggingFace(llm=llm)

result = model.invoke("Who is the president of the United States?")
print(result.content)
