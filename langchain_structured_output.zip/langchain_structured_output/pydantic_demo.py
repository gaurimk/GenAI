from pydantic import BaseModel, EmailStr,Field
from typing import Optional

class Student(BaseModel):
    name: str = 'Thomas'
    age: Optional[int] = None
    email: EmailStr
    cgpa: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=10.0)

new_student = {'age': '21','email':'abc@gmail.com'}
student = Student(**new_student)
student_dict = dict(student)
print(student_dict['age'])
student_json =student.model_dump_json()

